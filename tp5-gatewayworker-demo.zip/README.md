# tp5整合workerman/gatewayworker开发demo
使用方法：进入站点目录，执行php server.php start -d


worker配置文件在application/extra目录下

逻辑操作在application/push/controller/Event.php中，参考workerman官方demo即可